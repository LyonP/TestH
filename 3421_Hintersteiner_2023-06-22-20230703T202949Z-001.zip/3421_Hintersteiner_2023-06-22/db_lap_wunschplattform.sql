-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Erstellungszeit: 08. Feb 2023 um 16:43
-- Server-Version: 10.4.11-MariaDB
-- PHP-Version: 7.4.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Datenbank: `db_lap_wunschplattform`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tbl_teilen`
--

CREATE TABLE `tbl_teilen` (
  `IDTeilen` int(10) UNSIGNED NOT NULL,
  `FIDWunsch` int(10) UNSIGNED NOT NULL,
  `FIDUser` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `tbl_teilen`
--

INSERT INTO `tbl_teilen` (`IDTeilen`, `FIDWunsch`, `FIDUser`) VALUES
(2, 1, 2),
(3, 1, 3),
(1, 3, 2),
(6, 4, 2),
(5, 5, 1),
(4, 8, 1),
(9, 10, 2),
(10, 10, 3),
(7, 11, 1),
(8, 11, 2);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tbl_user`
--

CREATE TABLE `tbl_user` (
  `IDUser` int(10) UNSIGNED NOT NULL,
  `Nickname` varchar(32) NOT NULL,
  `Emailadresse` varchar(64) NOT NULL,
  `Passwort` varchar(255) NOT NULL,
  `Vorname` varchar(32) DEFAULT NULL,
  `Nachname` varchar(32) DEFAULT NULL,
  `Notiz` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `tbl_user`
--

INSERT INTO `tbl_user` (`IDUser`, `Nickname`, `Emailadresse`, `Passwort`, `Vorname`, `Nachname`, `Notiz`) VALUES
(1, 'uwemutz', 'uwe.mutz@syne.at', '$2y$10$Zn66AYjdvXXxFauNzcnvIeQGnqW2dygA6jlC4Si3KJRsTRLhe9n7m', 'Uwe', 'Mutz', 'test123'),
(2, 'silv', 'silvia.mutz@syne.at', '$2y$10$Sc/ldZMNGe0SvAz3SlpSouI2AUXirOkDJNoQO/JWblFdQxwfGyA4K', 'Silvia', NULL, 'test456'),
(3, 'tom', 'tom@syne.at', '$2y$10$Pe7re6cUYBlyDFTDc5fLn.xZU7q9ae70RN/cYHIXPk5cx5iOKH9Xa', NULL, NULL, 'test789');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tbl_veroeffentlichungsstati`
--

CREATE TABLE `tbl_veroeffentlichungsstati` (
  `IDVeroeffentlichungsstatus` int(10) UNSIGNED NOT NULL,
  `Bezeichnung` varchar(16) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `tbl_veroeffentlichungsstati`
--

INSERT INTO `tbl_veroeffentlichungsstati` (`IDVeroeffentlichungsstatus`, `Bezeichnung`) VALUES
(2, 'in Bearbeitung'),
(3, 'inaktiv'),
(1, 'veröffentlicht');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tbl_wuensche`
--

CREATE TABLE `tbl_wuensche` (
  `IDWunsch` int(10) UNSIGNED NOT NULL,
  `Titel` varchar(64) NOT NULL,
  `Beschreibung` text DEFAULT NULL,
  `URL` varchar(255) DEFAULT NULL,
  `Kosten` decimal(8,2) UNSIGNED NOT NULL,
  `isOeffentlich` tinyint(1) UNSIGNED NOT NULL DEFAULT 0,
  `Zeitpunkt` timestamp NOT NULL DEFAULT current_timestamp(),
  `Wichtigkeit` tinyint(1) UNSIGNED NOT NULL DEFAULT 1,
  `FIDStatus` int(10) UNSIGNED NOT NULL,
  `FIDUser` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `tbl_wuensche`
--

INSERT INTO `tbl_wuensche` (`IDWunsch`, `Titel`, `Beschreibung`, `URL`, `Kosten`, `isOeffentlich`, `Zeitpunkt`, `Wichtigkeit`, `FIDStatus`, `FIDUser`) VALUES
(1, 'E-Bike von UDX', 'Ein radikales E-Bike mit 4 Zoll fetten Reifen auf 20 Zoll Felgen.', 'https://www.udx.bike', '2500.00', 1, '2022-05-08 12:31:54', 4, 1, 1),
(2, 'Snowboard Rome Hammerhead 2013', 'Das Rome Hammerhead aus dem Jahr 2013 ist das tollste Snowboard der Welt. Muss ich haben!', NULL, '400.00', 1, '2021-02-10 13:31:54', 5, 1, 1),
(3, 'Album Nevermind von Nirvana', NULL, NULL, '10.00', 0, '2022-09-08 08:33:41', 4, 3, 1),
(4, 'Mac Pro 2019 in Bestkonfiguration', 'Wenn der Geldsegen eintritt', NULL, '90000.00', 1, '2019-12-24 13:33:41', 2, 1, 1),
(5, 'Gutscheine für einen Urlaub im Loisium', 'Ohne Erlebnisse ist das Leben nicht lebenswert. Das Loisium in Langenlois kommt da gerade richtig.', 'https://www.loisium.com/', '50.00', 0, '2023-01-08 13:35:45', 5, 1, 2),
(6, 'Alle Romy Schneider Filme', NULL, NULL, '10.00', 1, '2020-11-17 17:35:45', 2, 1, 2),
(7, 'Ducati Panigale V4 SP2', 'Ja, das wäre schon was :-)', 'https://www.ducati.com/ww/en/bikes/panigale/panigale-v4-sp2', '48000.00', 1, '2019-04-15 17:44:29', 2, 2, 1),
(8, 'Ein neues iPhone 14 Pro von Apple', NULL, 'https://www.apple.com/at/iphone-14-pro/', '1200.00', 1, '2022-05-02 19:45:00', 4, 1, 2),
(9, 'Spenden für Futter für alle Katzen der Welt', 'Support your local cats!', '', '20.00', 1, '2018-01-01 11:00:00', 5, 1, 2),
(10, 'Buch \"Der glückliche Tod\" von Albert Camus', 'Pflichtlektüre', NULL, '20.00', 1, '2019-10-17 12:46:13', 4, 3, 1),
(11, 'Vegan-Kochbuch', 'Vegan rules', NULL, '30.00', 1, '2023-02-08 13:46:13', 4, 1, 3);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tbl_wuensche_wunschlisten`
--

CREATE TABLE `tbl_wuensche_wunschlisten` (
  `IDWunschWunschliste` int(10) UNSIGNED NOT NULL,
  `FIDWunsch` int(10) UNSIGNED NOT NULL,
  `FIDWunschliste` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `tbl_wuensche_wunschlisten`
--

INSERT INTO `tbl_wuensche_wunschlisten` (`IDWunschWunschliste`, `FIDWunsch`, `FIDWunschliste`) VALUES
(2, 1, 1),
(1, 3, 9),
(4, 4, 7),
(3, 5, 10);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tbl_wunschlisten`
--

CREATE TABLE `tbl_wunschlisten` (
  `IDWunschliste` int(10) UNSIGNED NOT NULL,
  `Bezeichnung` varchar(64) NOT NULL,
  `Beschreibung` text DEFAULT NULL,
  `FIDUser` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `tbl_wunschlisten`
--

INSERT INTO `tbl_wunschlisten` (`IDWunschliste`, `Bezeichnung`, `Beschreibung`, `FIDUser`) VALUES
(1, 'Sport', NULL, 1),
(7, 'Technik', NULL, 1),
(8, 'Musik', NULL, 3),
(9, 'Musik', 'Alles rund im die Musik', 1),
(10, 'Freizeit', NULL, 2);

--
-- Indizes der exportierten Tabellen
--

--
-- Indizes für die Tabelle `tbl_teilen`
--
ALTER TABLE `tbl_teilen`
  ADD PRIMARY KEY (`IDTeilen`),
  ADD UNIQUE KEY `FIDWunsch` (`FIDWunsch`,`FIDUser`),
  ADD KEY `FIDUser` (`FIDUser`);

--
-- Indizes für die Tabelle `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`IDUser`),
  ADD UNIQUE KEY `Nickname` (`Nickname`),
  ADD UNIQUE KEY `Emailadresse` (`Emailadresse`);

--
-- Indizes für die Tabelle `tbl_veroeffentlichungsstati`
--
ALTER TABLE `tbl_veroeffentlichungsstati`
  ADD PRIMARY KEY (`IDVeroeffentlichungsstatus`),
  ADD UNIQUE KEY `Bezeichnung` (`Bezeichnung`);

--
-- Indizes für die Tabelle `tbl_wuensche`
--
ALTER TABLE `tbl_wuensche`
  ADD PRIMARY KEY (`IDWunsch`),
  ADD KEY `FIDStatus` (`FIDStatus`),
  ADD KEY `FIDUser` (`FIDUser`);

--
-- Indizes für die Tabelle `tbl_wuensche_wunschlisten`
--
ALTER TABLE `tbl_wuensche_wunschlisten`
  ADD PRIMARY KEY (`IDWunschWunschliste`),
  ADD UNIQUE KEY `FIDWunsch` (`FIDWunsch`,`FIDWunschliste`),
  ADD KEY `FIDWunschliste` (`FIDWunschliste`);

--
-- Indizes für die Tabelle `tbl_wunschlisten`
--
ALTER TABLE `tbl_wunschlisten`
  ADD PRIMARY KEY (`IDWunschliste`),
  ADD KEY `FIDUser` (`FIDUser`);

--
-- AUTO_INCREMENT für exportierte Tabellen
--

--
-- AUTO_INCREMENT für Tabelle `tbl_teilen`
--
ALTER TABLE `tbl_teilen`
  MODIFY `IDTeilen` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT für Tabelle `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `IDUser` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT für Tabelle `tbl_veroeffentlichungsstati`
--
ALTER TABLE `tbl_veroeffentlichungsstati`
  MODIFY `IDVeroeffentlichungsstatus` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT für Tabelle `tbl_wuensche`
--
ALTER TABLE `tbl_wuensche`
  MODIFY `IDWunsch` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT für Tabelle `tbl_wuensche_wunschlisten`
--
ALTER TABLE `tbl_wuensche_wunschlisten`
  MODIFY `IDWunschWunschliste` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT für Tabelle `tbl_wunschlisten`
--
ALTER TABLE `tbl_wunschlisten`
  MODIFY `IDWunschliste` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Constraints der exportierten Tabellen
--

--
-- Constraints der Tabelle `tbl_teilen`
--
ALTER TABLE `tbl_teilen`
  ADD CONSTRAINT `tbl_teilen_ibfk_1` FOREIGN KEY (`FIDWunsch`) REFERENCES `tbl_wuensche` (`IDWunsch`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_teilen_ibfk_2` FOREIGN KEY (`FIDUser`) REFERENCES `tbl_user` (`IDUser`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints der Tabelle `tbl_wuensche`
--
ALTER TABLE `tbl_wuensche`
  ADD CONSTRAINT `tbl_wuensche_ibfk_1` FOREIGN KEY (`FIDUser`) REFERENCES `tbl_user` (`IDUser`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_wuensche_ibfk_2` FOREIGN KEY (`FIDStatus`) REFERENCES `tbl_veroeffentlichungsstati` (`IDVeroeffentlichungsstatus`) ON UPDATE CASCADE;

--
-- Constraints der Tabelle `tbl_wuensche_wunschlisten`
--
ALTER TABLE `tbl_wuensche_wunschlisten`
  ADD CONSTRAINT `tbl_wuensche_wunschlisten_ibfk_1` FOREIGN KEY (`FIDWunsch`) REFERENCES `tbl_wuensche` (`IDWunsch`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_wuensche_wunschlisten_ibfk_2` FOREIGN KEY (`FIDWunschliste`) REFERENCES `tbl_wunschlisten` (`IDWunschliste`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints der Tabelle `tbl_wunschlisten`
--
ALTER TABLE `tbl_wunschlisten`
  ADD CONSTRAINT `tbl_wunschlisten_ibfk_1` FOREIGN KEY (`FIDUser`) REFERENCES `tbl_user` (`IDUser`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
