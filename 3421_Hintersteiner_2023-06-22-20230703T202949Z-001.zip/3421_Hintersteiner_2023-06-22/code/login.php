<?php
    // Session starten
    session_start();

    // Variable für Fehlmeldungen
    $fehlerMeldungen = [];

    $email = '';
    $passwort = '';

    // Überprüfung ob die Seite mittels POST-Request aufgerufen wurde
    if (count($_POST) > 0) {
        // Daten aus dem abgesendeten Formular auslesen
        $email = $_POST['email'];
        $passwort = $_POST['passwort'];

        // TODO: Validierung der Daten aus dem Formular
        $validierungOk = true;

        // Wenn Validierung OK, dann speichern der Daten in die Datenbank
        if ($validierungOk) {
            // Datenbankverbindung "importieren"
            require_once('includes/conn.inc.php');

            // Datenbankverbindung ist aufgebaut
            // Nächster Schritt: Suche des Benutzers anhander der Email-Adresse in der DB
            // SQL-Statement erstellen
            $sql = "SELECT * FROM tbl_user WHERE Emailadresse LIKE '$email'";

            // SQL-Statement ausführen und das Ergebnis in einer Variable speichern
            $result = $conn->query($sql);

            // wenn das Result != false -> Statement erfolgreich, aber es könnte auch ein leeres Resultat zurückkommen
            // $result->num_rows gibt die Anzahl der zurückgelieferten Datensätze an
            // wenn $result->num_rows == 1, dann wurde genau ein Datensatz (User) gefunden
            if ($result && $result->num_rows == 1) {
                // Datensatz in eine Variable speichern
                /*
                    $user = [
                        'IDUser'   => 1,
                        'Username' => 'Max',
                        'Email'    => 'max@muster.at',
                        'Passwort' => '$2y$10$27jce...'
                    ]
                */
                $user = $result->fetch_assoc();
                
                // Passwort prüfen
                if (password_verify($passwort, $user['Passwort'])) {
                    // User in der Session speichern
                    $_SESSION['user'] = $user;

                    // erfolgreich -> Weiterleitung auf index.php
                    header('Location: meine_wuensche.php');
                }
            } 
            
            // Fehlermeldung ausgeben (wenn Anmeldung nicht erfolgreich)
            // z.B. weil der Benutzer nicht gefunden wurde oder das Passwort nicht übereinstimmt
            $fehlerMeldungen[] = 'Die eingegebenen Daten waren nicht korrekt.';
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
</head>
<body>
    <?php include ('includes/navigation.php'); ?>
    
    <h1>Login</h1>

    <?php if (count($fehlerMeldungen) > 0): ?>
        <?php foreach ($fehlerMeldungen as $fehlerMeldung): ?>
            <div class="error">
                <?php echo $fehlerMeldung; ?>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>

    <form action="login.php" method="POST">
        <div class="form-field">
            <label for="email">Email</label>
            <input type="email" name="email" id="email" value="<?php echo $email; ?>" required>
        </div>
        <div class="form-field">
            <label for="passwort">Passwort</label>
            <input type="password" name="passwort" id="passwort" value="<?php echo $passwort; ?>" required>
        </div>
        <button type="submit">Anmelden</button>
    </form>
</body>
</html>