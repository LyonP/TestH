<?php

    // Überprüfung ob die Seite mittels POST-Request aufgerufen wurde
    if (count($_POST) > 0) {
        // Daten aus dem abgesendeten Formular auslesen
        $username = $_POST['username'];
        $email = $_POST['email'];
        $passwort = $_POST['passwort'];

        // TODO: Validierung der Daten aus dem Formular
        $validierungOk = true;

        // Wenn Validierung OK, dann speichern der Daten in die Datenbank
        if ($validierungOk) {
            // Datenbankverbindung "importieren"
            require_once('includes/conn.inc.php');

            // Passwort-Hash generieren
            $passwortHash = password_hash($passwort, PASSWORD_BCRYPT);

            // Datenbankverbindung ist aufgebaut
            // Nächster Schritt: Daten in die Datenbank speichern
            // SQL-Statement erstellen
            $sql = "INSERT INTO tbl_user (Nickname, Emailadresse, Passwort)
                    VALUES ('$username', '$email', '$passwortHash')";

            // SQL-Statement ausführen und das Ergebnis in einer Variable speichern
            $result = $conn->query($sql);

            // wenn das Result != false -> Statement erfolgreich
            if ($result) {
                // erfolgreich -> Weiterleitung auf login.php
                header('Location: login.php');
            } else {
                // Fehlermeldung ausgeben
            }
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrierung</title>
</head>
<body>
    <h1>Registrierung</h1>
    <form action="registrierung.php" method="POST">
        <div class="form-field">
            <label for="username">Username</label>
            <input type="text" name="username" id="username" required>
        </div>
        <div class="form-field">
            <label for="email">Email</label>
            <input type="email" name="email" id="email" required>
        </div>
        <div class="form-field">
            <label for="passwort">Passwort</label>
            <input type="password" name="passwort" id="passwort" required>
        </div>
        <button type="submit">Absenden</button>
    </form>
</body>
</html>