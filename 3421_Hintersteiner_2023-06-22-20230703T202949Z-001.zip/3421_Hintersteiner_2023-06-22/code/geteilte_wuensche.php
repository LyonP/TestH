<?php
    // Session starten
    session_start();

    // ist in der Session ein User enthalten?
    $user = $_SESSION['user'] ?? null;

    if (!$user) {
        header('Location: login.php');
        die();
    }

    // Verbindung zur Datenbank aufbauen (Einbinden des entsprechenden Scripts)
    require_once('includes/conn.inc.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Geteilten Wünsche</title>
</head>
<body>
    <?php include ('includes/navigation.php'); ?>

    <?php if ($user): ?>
       <p>angemeldet als <?php echo $user['Nickname']; ?> | <a href="logout.php">Abmelden</a></p> 
    <?php endif; ?>
    
    <h2>Geteilte Wünsche</h2>

    <form action="" method="get">
        <label for="user-filter">nur geteilte Wünsche dieses Users anzeigen</label><br>
        <select name="user-filter" id="user-filter">
            <option value="">Bitte wählen</option>
            <?php
                $sqlUser = "SELECT * FROM tbl_user
                            WHERE IDUser != " . $user['IDUser'] . "
                            ORDER BY Nickname ASC";

                $resultUsers = $conn->query($sqlUser);
            ?>
            <?php if ($resultUsers && $resultUsers->num_rows > 0): ?>
                <?php while ($otherUser = $resultUsers->fetch_assoc()): ?>
                    <option value="<?php echo $otherUser['IDUser']; ?>"><?php echo $otherUser['Nickname']; ?></option>
                <?php endwhile; ?>
            <?php endif; ?>
        </select>
        <br>
        <button type="submit">filtern</button>
    </form>

    <?php
        $userFilter = (int) $_GET['user-filter'] ?? 0;

        if ($userFilter) {
            $sql = "SELECT tbl_wuensche.*, tbl_user.* FROM tbl_wuensche
                    JOIN tbl_user ON tbl_wuensche.FIDUser = tbl_user.IDUser
                    JOIN tbl_teilen ON tbl_wuensche.IDWunsch = tbl_teilen.FIDWunsch
                    WHERE tbl_teilen.FIDUser = " . $user['IDUser'] . " AND tbl_wuensche.FIDUser = $userFilter
                    ORDER BY Titel ASC";
        } else {
            $sql = "SELECT tbl_wuensche.*, tbl_user.* FROM tbl_wuensche
                    JOIN tbl_user ON tbl_wuensche.FIDUser = tbl_user.IDUser
                    JOIN tbl_teilen ON tbl_wuensche.IDWunsch = tbl_teilen.FIDWunsch
                    WHERE tbl_teilen.FIDUser = " . $user['IDUser'] . "
                    ORDER BY Titel ASC";
        }
        // SQL-Statement an die Datenbank übermitteln + ausführen und das Ergebnis
        // in der Variable $result ablegen
        $result = $conn->query($sql);

        // Ergebnis != false -> dann war das SQL Statement erfolgreich
        // Auch wenn ein leeres Ergebnis von der Datenbank zurückkommen würde,
        // wäre es != false
    ?>
    <?php if ($result): ?>
        <ul>
            <?php while ($wunsch = $result->fetch_assoc()): ?>
                <li>
                    <?php echo $wunsch['Zeitpunkt']; ?> | von <?php echo $wunsch['Nickname']; ?>
                    <br>
                    <strong>
                        <?php echo $wunsch['Titel']; ?> | <?php echo $wunsch['Wichtigkeit']; ?> Sterne
                    </strong>
                    <br>
                    <em><?php echo $wunsch['Beschreibung']; ?></em>
                    <?php if (!empty($wunsch['URL'])): ?>
                        <br>
                        <a href="<?php echo $wunsch['URL'] ?>">Details</a>
                    <?php endif; ?>
                    <br>
                    Kosten ca. EUR <?php echo $wunsch['Kosten'] ?>
                </li>
            <?php endwhile; ?>

        </ul>

    <?php endif; ?>
</body>
</html>