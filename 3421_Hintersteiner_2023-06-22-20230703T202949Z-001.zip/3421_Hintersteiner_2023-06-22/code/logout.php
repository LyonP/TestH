<?php
    // Session starten
    session_start();

    // Session beenden
    session_destroy();

    // Weiterleitung auf login.php
    header('Location: login.php');