<?php

// Datenbankverbindung aufbauen
$conn = new mysqli('localhost', 'root', '', 'db_lap_wunschplattform');

// Überprüfen ob die Datenbankverbindung fehlgeschlagen ist -> PHP Script abbrechen
if ($conn->connect_errno) {
    die('Beim Verbinden zur DB ist ein Fehler aufgetreten.');
}

// Zeichensatz für Datenbankverbindung festlegen
$conn->set_charset('utf8mb4');