<?php
    // Verbindung zur Datenbank aufbauen (Einbinden des entsprechenden Scripts)
    require_once('includes/conn.inc.php');

    // Damit zwei Tabellen miteinander verknüpft werden könnne, müssen sie mittels
    // JOIN verbunden werden. Beim Join selbst wird angegeben, über welche Spalten
    // aus beiden Tabellen die Beziehung zueinander hergestellt wird
    // JOIN tbl_user ON tbl_wuensche.FIDUser = tbl_user.IDUser

    $sql = "SELECT * FROM tbl_wuensche
            JOIN tbl_user ON tbl_wuensche.FIDUser = tbl_user.IDUser
            WHERE isOeffentlich = 1
            ORDER BY Zeitpunkt DESC";

    // SQL-Statement an die Datenbank übermitteln + ausführen und das Ergebnis
    // in der Variable $result ablegen
    $result = $conn->query($sql);

    // leeres Array, in das alle Wünsche aus der Datenbank eingefügt werden sollen
    $wuensche = [];

    // Ergebnis != false -> dann war das SQL Statement erfolgreich
    // Auch wenn ein leeres Ergebnis von der Datenbank zurückkommen würde,
    // wäre es != false
    if ($result) {
        // Alle Zeilen aus dem Ergebnis abrufen und in ein Array speichern
        // $wunsch = $result->fetch_assoc() liest einen Datensatz aus der Datenbank aus und speichert
        // es in der Variable $wunsch.
        // wenn kein weiterer Datensatz gefunden wird, dann bekommt die Variable $wunsch den Wert null
        while ($wunsch = $result->fetch_assoc()) {
            // zu Wünsche Array wird der gerade ausgelesene Datensatz am Ende hinzugefügt
            $wuensche[] = $wunsch;
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Öffentliche Wünsche</title>
</head>
<body>
    <?php include ('includes/navigation.php'); ?>
    <ul>
        <?php foreach ($wuensche as $wunsch): ?>
            <li>
                <?php echo $wunsch['Zeitpunkt']; ?> | 
                <a href="mailto:<?php echo $wunsch['Emailadresse'] ?>">
                    <?php echo $wunsch['Nickname']; ?>
                </a>
                <br>
                <strong>
                    <?php echo $wunsch['Titel']; ?> | <?php echo $wunsch['Wichtigkeit']; ?> Sterne
                </strong>
                <br>
                <em><?php echo $wunsch['Beschreibung']; ?></em>
                <?php if (!empty($wunsch['URL'])): ?>
                    <br>
                    <a href="<?php echo $wunsch['URL'] ?>">Details</a>
                <?php endif; ?>
                <br>
                Kosten ca. EUR <?php echo $wunsch['Kosten'] ?>
            </li>
        <?php endforeach; ?>
    </ul>
</body>
</html>