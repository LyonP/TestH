<?php
    // Session starten
    session_start();

    // ist in der Session ein User enthalten?
    $user = $_SESSION['user'] ?? null;

    if (!$user) {
        header('Location: login.php');
        die();
    }

    // Verbindung zur Datenbank aufbauen (Einbinden des entsprechenden Scripts)
    require_once('includes/conn.inc.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Meine Wünsche</title>
</head>
<body>
    <?php include ('includes/navigation.php'); ?>

    <?php if ($user): ?>
       <p>angemeldet als <?php echo $user['Nickname']; ?> | <a href="logout.php">Abmelden</a></p> 
    <?php endif; ?>
    
    <h2>Nicht zugeordnete Wünsche</h2>
    <?php
        $sql = "SELECT * FROM tbl_wuensche
                WHERE FIDUser = " . $user['IDUser'] . " AND IDWunsch NOT IN (
                    SELECT FIDWunsch FROM tbl_wuensche_wunschlisten
                )
                ORDER BY Titel ASC";

        // SQL-Statement an die Datenbank übermitteln + ausführen und das Ergebnis
        // in der Variable $result ablegen
        $result = $conn->query($sql);

        // Ergebnis != false -> dann war das SQL Statement erfolgreich
        // Auch wenn ein leeres Ergebnis von der Datenbank zurückkommen würde,
        // wäre es != false
    ?>
    <?php if ($result): ?>
        <ul>

            <?php while ($wunsch = $result->fetch_assoc()): ?>
                <li>
                    <?php echo $wunsch['Zeitpunkt']; ?>
                    <br>
                    <strong>
                        <?php echo $wunsch['Titel']; ?> | <?php echo $wunsch['Wichtigkeit']; ?> Sterne
                    </strong>
                    <br>
                    <em><?php echo $wunsch['Beschreibung']; ?></em>
                    <?php if (!empty($wunsch['URL'])): ?>
                        <br>
                        <a href="<?php echo $wunsch['URL'] ?>">Details</a>
                    <?php endif; ?>
                    <br>
                    Kosten ca. EUR <?php echo $wunsch['Kosten'] ?>

                    <?php
                        $sqlGeteiltMit = "SELECT * FROM tbl_user
                                          JOIN tbl_teilen ON tbl_teilen.FIDUser = tbl_user.IDUser
                                          WHERE FIDWunsch = " . $wunsch['IDWunsch'];

                        $resultGeteiltMit = $conn->query($sqlGeteiltMit);
                    ?>
                    <?php if ($resultGeteiltMit && $resultGeteiltMit->num_rows > 0): ?>
                        <ul>
                            <?php while ($geteiltMit = $resultGeteiltMit->fetch_assoc()): ?>
                                <li>
                                    <?php echo $geteiltMit['Nickname']; ?>
                                </li>        
                            <?php endwhile; ?>
                        </ul>
                    <?php endif; ?>
                </li>
            <?php endwhile; ?>

        </ul>

    <?php endif; ?>

    <h2>Wunschlisten</h2>
    <?php
        $sql = "SELECT * FROM tbl_wunschlisten 
                WHERE FIDUser = " . $user['IDUser'] . "
                ORDER BY Bezeichnung ASC";

        // SQL-Statement an die Datenbank übermitteln + ausführen und das Ergebnis
        // in der Variable $result ablegen
        $result = $conn->query($sql);

        // Ergebnis != false -> dann war das SQL Statement erfolgreich
        // Auch wenn ein leeres Ergebnis von der Datenbank zurückkommen würde,
        // wäre es != false
    ?>
    <?php if ($result && $result->num_rows > 0): ?>
        
        <?php while ($wunschliste = $result->fetch_assoc()): ?>
            <h3><?php echo $wunschliste['Bezeichnung']; ?></h3>

            <?php
                $sqlWuensche = "SELECT * FROM tbl_wuensche
                        JOIN tbl_wuensche_wunschlisten ON tbl_wuensche_wunschlisten.FIDWunsch = tbl_wuensche.IDWunsch
                        WHERE FIDWunschliste = " . $wunschliste['IDWunschliste'] . " 
                        ORDER BY Titel ASC";

                // SQL-Statement an die Datenbank übermitteln + ausführen und das Ergebnis
                // in der Variable $result ablegen
                $resultWuensche = $conn->query($sqlWuensche);

                // Ergebnis != false -> dann war das SQL Statement erfolgreich
                // Auch wenn ein leeres Ergebnis von der Datenbank zurückkommen würde,
                // wäre es != false
            ?>
            <?php if ($resultWuensche): ?>
                <ul>

                    <?php while ($wunsch = $resultWuensche->fetch_assoc()): ?>
                        <li>
                            <?php echo $wunsch['Zeitpunkt']; ?>
                            <br>
                            <strong>
                                <?php echo $wunsch['Titel']; ?> | <?php echo $wunsch['Wichtigkeit']; ?> Sterne
                            </strong>
                            <br>
                            <em><?php echo $wunsch['Beschreibung']; ?></em>
                            <?php if (!empty($wunsch['URL'])): ?>
                                <br>
                                <a href="<?php echo $wunsch['URL'] ?>">Details</a>
                            <?php endif; ?>
                            <br>
                            Kosten ca. EUR <?php echo $wunsch['Kosten'] ?>

                            <?php
                                $sqlGeteiltMit = "SELECT * FROM tbl_user
                                                JOIN tbl_teilen ON tbl_teilen.FIDUser = tbl_user.IDUser
                                                WHERE FIDWunsch = " . $wunsch['IDWunsch'];

                                $resultGeteiltMit = $conn->query($sqlGeteiltMit);
                            ?>
                            <?php if ($resultGeteiltMit && $resultGeteiltMit->num_rows > 0): ?>
                                <ul>
                                    <?php while ($geteiltMit = $resultGeteiltMit->fetch_assoc()): ?>
                                        <li>
                                            <?php echo $geteiltMit['Nickname']; ?>
                                        </li>        
                                    <?php endwhile; ?>
                                </ul>
                            <?php endif; ?>
                        </li>
                    <?php endwhile; ?>

                </ul>

            <?php endif; ?>

        <?php endwhile; ?>

    <?php endif; ?>
</body>
</html>