-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Erstellungszeit: 15. Jun 2023 um 20:14
-- Server-Version: 10.4.28-MariaDB
-- PHP-Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Datenbank: `db_wunschliste`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tbl_user`
--

CREATE TABLE `tbl_user` (
  `IDUser` int(10) UNSIGNED NOT NULL,
  `Username` varchar(64) NOT NULL,
  `Email` varchar(64) NOT NULL,
  `Passwort` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Daten für Tabelle `tbl_user`
--

INSERT INTO `tbl_user` (`IDUser`, `Username`, `Email`, `Passwort`) VALUES
(1, 'max', 'max@muster.at', '$2y$10$27jceVWt5gTfWIGolxaWW.koiRMaFIm.pcatLKJMHz9A1XHOvQKde'),
(2, 'susi', 'susi@muster.at', '$2y$10$sWGjo5H3492Fy3pVAU/PneoFRC/Weez2VarW54NZyh2W9UepAHRDO');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tbl_wunsch`
--

CREATE TABLE `tbl_wunsch` (
  `IDWunsch` int(10) UNSIGNED NOT NULL,
  `Wunsch` varchar(64) NOT NULL,
  `ErstelltAm` datetime NOT NULL DEFAULT current_timestamp(),
  `FIDUser` int(10) UNSIGNED NOT NULL,
  `FIDWunschliste` int(10) UNSIGNED DEFAULT NULL,
  `Preis` decimal(10,2) NOT NULL DEFAULT 0.00,
  `Status` set('veröffentlicht','privat') NOT NULL DEFAULT 'privat',
  `Details` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tbl_wunschliste`
--

CREATE TABLE `tbl_wunschliste` (
  `IDWunschliste` int(10) UNSIGNED NOT NULL,
  `Bezeichnung` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Daten für Tabelle `tbl_wunschliste`
--

INSERT INTO `tbl_wunschliste` (`IDWunschliste`, `Bezeichnung`) VALUES
(1, 'Musik'),
(2, 'Sport'),
(3, 'Technik');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tbl_wunsch_geteilt_mit_user`
--

CREATE TABLE `tbl_wunsch_geteilt_mit_user` (
  `ID` int(11) NOT NULL,
  `FIDWunsch` int(10) UNSIGNED NOT NULL,
  `FIDUser` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indizes der exportierten Tabellen
--

--
-- Indizes für die Tabelle `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`IDUser`),
  ADD UNIQUE KEY `Username` (`Username`,`Email`);

--
-- Indizes für die Tabelle `tbl_wunsch`
--
ALTER TABLE `tbl_wunsch`
  ADD PRIMARY KEY (`IDWunsch`),
  ADD KEY `FIDUser` (`FIDUser`,`FIDWunschliste`),
  ADD KEY `FIDWunschliste` (`FIDWunschliste`);

--
-- Indizes für die Tabelle `tbl_wunschliste`
--
ALTER TABLE `tbl_wunschliste`
  ADD PRIMARY KEY (`IDWunschliste`);

--
-- Indizes für die Tabelle `tbl_wunsch_geteilt_mit_user`
--
ALTER TABLE `tbl_wunsch_geteilt_mit_user`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `FIDWunsch` (`FIDWunsch`,`FIDUser`),
  ADD KEY `FIDUser` (`FIDUser`);

--
-- AUTO_INCREMENT für exportierte Tabellen
--

--
-- AUTO_INCREMENT für Tabelle `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `IDUser` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT für Tabelle `tbl_wunsch`
--
ALTER TABLE `tbl_wunsch`
  MODIFY `IDWunsch` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT für Tabelle `tbl_wunschliste`
--
ALTER TABLE `tbl_wunschliste`
  MODIFY `IDWunschliste` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT für Tabelle `tbl_wunsch_geteilt_mit_user`
--
ALTER TABLE `tbl_wunsch_geteilt_mit_user`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints der exportierten Tabellen
--

--
-- Constraints der Tabelle `tbl_wunsch`
--
ALTER TABLE `tbl_wunsch`
  ADD CONSTRAINT `tbl_wunsch_ibfk_1` FOREIGN KEY (`FIDUser`) REFERENCES `tbl_user` (`IDUser`) ON DELETE CASCADE,
  ADD CONSTRAINT `tbl_wunsch_ibfk_2` FOREIGN KEY (`FIDWunschliste`) REFERENCES `tbl_wunschliste` (`IDWunschliste`) ON DELETE SET NULL;

--
-- Constraints der Tabelle `tbl_wunsch_geteilt_mit_user`
--
ALTER TABLE `tbl_wunsch_geteilt_mit_user`
  ADD CONSTRAINT `tbl_wunsch_geteilt_mit_user_ibfk_1` FOREIGN KEY (`FIDUser`) REFERENCES `tbl_user` (`IDUser`) ON DELETE CASCADE,
  ADD CONSTRAINT `tbl_wunsch_geteilt_mit_user_ibfk_2` FOREIGN KEY (`FIDWunsch`) REFERENCES `tbl_wunsch` (`IDWunsch`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
