<?php
require("includes/config.inc.php");
require("includes/conn.inc.php");
?>