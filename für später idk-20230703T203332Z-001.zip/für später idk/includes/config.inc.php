<?php
define("MAXSIZE", 700000);
define("FILETYPES", array(
    "image/jpeg",
    "image/gif",
    "image/png",
    "application/pdf")
);

define("DATADIR","./daten/")
?>