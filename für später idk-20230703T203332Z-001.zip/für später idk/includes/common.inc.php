<?php
function ta($in) {
    echo('<pre class="ta">');
    print_r($in);
    echo('</pre>');
}
?>